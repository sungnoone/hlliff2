import React from 'react';
import ReactDOM from 'react-dom';
import SampleApp from './sampleapp.js';


ReactDOM.render(<SampleApp/>, document.getElementById('root'));